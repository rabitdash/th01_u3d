﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleController : MonoBehaviour
{
    //战斗逻辑部分
    //变量定义
    //public static string message = null; //UIController从外部将消息写入message
    //public setPlayerTurn(int playerNum)
    public 

    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        //while (message != null)
        {
        //    Debug.Log(message);
        //    message = null;//清空message
        }
    }
    

}
